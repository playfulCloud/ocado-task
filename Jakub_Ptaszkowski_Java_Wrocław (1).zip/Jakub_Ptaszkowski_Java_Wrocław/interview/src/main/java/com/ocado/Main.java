package com.ocado;

import com.ocado.basket.BasketSplitter;
import com.ocado.utils.JsonParser;

import java.util.List;
import java.util.Map;

public class Main {
    public static void main(String[] args) {
        var splitter = new BasketSplitter("/home/playfulCloud/IdeaProjects/ocado-info/Zadanie/config.json");
//        splitter.displayMapping(splitter.getProductAndShipmentMethods());
        List<String>sampleData = List.of("Cocoa Butter", "Tart - Raisin And Pecan", "Table Cloth 54x72 White", "Flower - Daisies", "Fond - Chocolate", "Cookies - Englishbay Wht");
        List<String>sampleData1 = List.of("Cocoa Butter");
        List<String>sampleData3 = List.of();
        List<String>sampleData2 = List.of("Fond - Chocolate", "Chocolate - Unsweetened", "Nut - Almond, Blanched, Whole", "Haggis", "Mushroom - Porcini Frozen", "Cake - Miini Cheesecake Cherry", "Sauce - Mint", "Longan", "Bag Clear 10 Lb", "Nantucket - Pomegranate Pear", "Puree - Strawberry", "Numi - Assorted Teas", "Apples - Spartan", "Garlic - Peeled", "Cabbage - Nappa", "Bagel - Whole White Sesame", "Tea - Apple Green Tea");
//        System.out.println(sampleData.size());
        System.out.println(splitter.split(sampleData2));
    }
}