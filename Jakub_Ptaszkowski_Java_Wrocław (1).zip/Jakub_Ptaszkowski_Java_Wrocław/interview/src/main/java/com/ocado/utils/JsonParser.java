package com.ocado.utils;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class JsonParser {

    public Map<String, List<String>> parseJson(String absolutePathToFile){
        ObjectMapper mapper = new ObjectMapper();
        Map<String, List<String>> result = null;

        try {
            result = mapper.readValue(new File(absolutePathToFile), Map.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }
}
