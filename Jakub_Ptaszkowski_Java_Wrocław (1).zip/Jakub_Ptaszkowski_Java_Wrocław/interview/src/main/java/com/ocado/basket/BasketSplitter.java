package com.ocado.basket;

import com.ocado.utils.JsonParser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BasketSplitter {

    private final Map<String, List<String>> productAndShipmentMethods;
    private final Map<String, List<String>> result = new HashMap<>();

    public BasketSplitter(String absolutePathToConfigFile) {
        JsonParser parser = new JsonParser();
        this.productAndShipmentMethods = parser.parseJson(absolutePathToConfigFile);
    }

    public Map<String, List<String>> split(List<String> items) {
        if(items == null){
            throw new RuntimeException("Provided list is null");
        }
        List<String> itemsToCompute = new ArrayList<>(items);
        Map<String, Integer> currentDeliverersAndProducts;

        while (!itemsToCompute.isEmpty()) {
            currentDeliverersAndProducts = countCapacity(itemsToCompute);
            String currentBiggest = findBiggestCapacityDeliverer(currentDeliverersAndProducts);
            itemsToCompute = subtractCurrentBiggestDelivererFrom(currentBiggest, itemsToCompute, currentDeliverersAndProducts);
        }

        return result;
    }

    private Map<String, Integer> countCapacity(List<String> products) {
        Map<String, Integer> capacityCount = new HashMap<>();
        for (String product : products) {
            List<String> deliverers = productAndShipmentMethods.getOrDefault(product, new ArrayList<>());
            for (String deliverer : deliverers) {
                capacityCount.merge(deliverer, 1, Integer::sum);
            }
        }
        return capacityCount;
    }

    private String findBiggestCapacityDeliverer(Map<String, Integer> deliverersAndProducts) {
        return deliverersAndProducts.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse(null);
    }

    private List<String> subtractCurrentBiggestDelivererFrom(String deliverer, List<String> products, Map<String, Integer> capacityCount) {
        List<String> remainingProducts = new ArrayList<>();
        List<String> allocatedProducts = new ArrayList<>();

        for (String product : products) {
            if (productAndShipmentMethods.getOrDefault(product, new ArrayList<>()).contains(deliverer)) {
                allocatedProducts.add(product);
            } else {
                remainingProducts.add(product);
            }
        }

        if (!allocatedProducts.isEmpty()) {
            result.put(deliverer, allocatedProducts);
        }

        return remainingProducts;
    }
}
