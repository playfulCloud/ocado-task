package com.ocado.basket;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class BasketSplitterTest {

    private BasketSplitter basketSplitter;
   private final String PATH_TO_CONFIG = getClass().getClassLoader().getResource("config.json").getFile();

    @BeforeEach
    void setUp() {
        basketSplitter = new BasketSplitter(PATH_TO_CONFIG);
    }

    @Test
    void splitSingleProduct() {
        List<String> items = Arrays.asList("Cocoa Butter");
        Map<String, List<String>> expected = Map.of("Parcel locker", List.of("Cocoa Butter"));

        Map<String, List<String>> result = basketSplitter.split(items);

        assertEquals(expected, result);
    }

    @Test
    void splitExceptionThrown() {
        List<String> items = null;
        Exception exception = assertThrows(RuntimeException.class, () -> basketSplitter.split(items));
    }

    @Test
    void splitMultipleProductsProvidedBasket1() {
        List<String> items = List.of("Cocoa Butter", "Tart - Raisin And Pecan", "Table Cloth 54x72 White", "Flower - Daisies", "Fond - Chocolate", "Cookies - Englishbay Wht");
        Map<String, List<String>> expected = Map.of(
                "Pick-up point", Arrays.asList("Fond - Chocolate"),
                "Courier", Arrays.asList("Cocoa Butter", "Tart - Raisin And Pecan", "Table Cloth 54x72 White", "Flower - Daisies", "Cookies - Englishbay Wht")
        );

        Map<String, List<String>> result = basketSplitter.split(items);

        assertEquals(expected, result);
    }

    @Test
    void splitMultipleProductsProvidedBasket2() {
        List<String> items = List.of("Fond - Chocolate", "Chocolate - Unsweetened", "Nut - Almond, Blanched, Whole", "Haggis", "Mushroom - Porcini Frozen", "Cake - Miini Cheesecake Cherry", "Sauce - Mint", "Longan", "Bag Clear 10 Lb", "Nantucket - Pomegranate Pear", "Puree - Strawberry", "Numi - Assorted Teas", "Apples - Spartan", "Garlic - Peeled", "Cabbage - Nappa", "Bagel - Whole White Sesame", "Tea - Apple Green Tea");
        Map<String, List<String>> expected = Map.of(
                "Courier", Arrays.asList("Cake - Miini Cheesecake Cherry"),
                "Same day delivery", Arrays.asList("Sauce - Mint", "Numi - Assorted Teas", "Garlic - Peeled"),
                "Express Collection",Arrays.asList("Fond - Chocolate", "Chocolate - Unsweetened", "Nut - Almond, Blanched, Whole", "Haggis", "Mushroom - Porcini Frozen", "Longan", "Bag Clear 10 Lb", "Nantucket - Pomegranate Pear", "Puree - Strawberry", "Apples - Spartan", "Cabbage - Nappa", "Bagel - Whole White Sesame", "Tea - Apple Green Tea")
        );

        Map<String, List<String>> result = basketSplitter.split(items);

        assertEquals(expected, result);
    }

    @Test
    void splitNoProducts() {
        List<String> items = Arrays.asList();
        Map<String, List<String>> expected = Map.of();

        Map<String, List<String>> result = basketSplitter.split(items);

        assertTrue(result.isEmpty());
    }
}
